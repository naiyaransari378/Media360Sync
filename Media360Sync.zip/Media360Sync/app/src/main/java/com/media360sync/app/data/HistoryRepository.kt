package com.media360sync.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val id: Long,
    val title: String,
    val uri: String,
    val mime: String,
    val platform: String,
    val sourceUrl: String,
    val time: Long,
    val size: Long,
) {
    val isAudio get() = mime.startsWith("audio")
}

class HistoryRepository private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("history", Context.MODE_PRIVATE)
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<HistoryItem>> = _items.asStateFlow()

    @Synchronized
    fun add(item: HistoryItem) {
        _items.value = (listOf(item) + _items.value).take(500); persist()
    }

    @Synchronized
    fun remove(id: Long) {
        _items.value = _items.value.filterNot { it.id == id }; persist()
    }

    @Synchronized
    fun clear() {
        _items.value = emptyList(); persist()
    }

    private fun load(): List<HistoryItem> = runCatching {
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryItem(
                id = o.getLong("id"), title = o.getString("title"), uri = o.getString("uri"),
                mime = o.getString("mime"), platform = o.optString("platform", "Web"),
                sourceUrl = o.optString("source", ""), time = o.getLong("time"), size = o.optLong("size", 0),
            )
        }
    }.getOrDefault(emptyList())

    private fun persist() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("uri", it.uri).put("mime", it.mime)
                    .put("platform", it.platform).put("source", it.sourceUrl).put("time", it.time).put("size", it.size)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    companion object {
        private const val KEY = "items"
        @Volatile private var instance: HistoryRepository? = null
        fun get(context: Context): HistoryRepository =
            instance ?: synchronized(this) {
                instance ?: HistoryRepository(context.applicationContext).also { instance = it }
            }
    }
}
