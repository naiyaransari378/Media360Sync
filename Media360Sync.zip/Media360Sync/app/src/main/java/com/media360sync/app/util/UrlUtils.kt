package com.media360sync.app.util

import android.net.Uri
import java.text.DateFormat
import java.util.Date
import java.util.Locale

enum class Platform(val label: String, val color: Long) {
    YOUTUBE("YouTube", 0xFFFF4D4D),
    INSTAGRAM("Instagram", 0xFFE1306C),
    TIKTOK("TikTok", 0xFF25F4EE),
    FACEBOOK("Facebook", 0xFF4C8DFF),
    X("X", 0xFFE7E9EA),
    REDDIT("Reddit", 0xFFFF6A2B),
    VIMEO("Vimeo", 0xFF1AB7EA),
    OTHER("Web", 0xFF8B5CF6);

    companion object {
        val featured = listOf(YOUTUBE, INSTAGRAM, TIKTOK, FACEBOOK, X)
    }
}

object UrlUtils {
    private val urlRegex = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)

    fun extractUrl(text: String?): String? =
        text?.let { urlRegex.find(it)?.value?.trimEnd('.', ',', ')', ']', '!', ';') }

    fun detect(url: String?): Platform {
        if (url.isNullOrBlank()) return Platform.OTHER
        val host = runCatching { Uri.parse(url).host?.lowercase() }.getOrNull() ?: return Platform.OTHER
        return when {
            host.contains("youtube.") || host == "youtu.be" -> Platform.YOUTUBE
            host.contains("instagram.") || host == "instagr.am" -> Platform.INSTAGRAM
            host.contains("tiktok.") -> Platform.TIKTOK
            host.contains("facebook.") || host == "fb.watch" -> Platform.FACEBOOK
            host == "x.com" || host.endsWith(".x.com") || host.contains("twitter.") -> Platform.X
            host.contains("reddit.") || host == "redd.it" -> Platform.REDDIT
            host.contains("vimeo.") -> Platform.VIMEO
            else -> Platform.OTHER
        }
    }
}

object Fmt {
    fun bytes(b: Long): String {
        if (b <= 0) return "—"
        val units = arrayOf("B", "KB", "MB", "GB")
        var v = b.toDouble(); var i = 0
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return String.format(Locale.US, if (i == 0) "%.0f %s" else "%.1f %s", v, units[i])
    }

    fun eta(seconds: Long): String {
        if (seconds <= 0) return ""
        val m = seconds / 60; val s = seconds % 60
        return if (m >= 60) String.format(Locale.US, "%d:%02d:%02d", m / 60, m % 60, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    /** Player clock: 3:07 or 1:02:45 */
    fun clock(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600; val m = (total % 3600) / 60; val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun dateTime(millis: Long): String =
        if (millis <= 0) "Never"
        else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(Date(millis))
}
