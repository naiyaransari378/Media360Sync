package com.media360sync.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.data.HistoryItem
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.components.EqualizerBars
import com.media360sync.app.ui.components.GlassButton
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.GradientButton
import com.media360sync.app.ui.components.MediaThumb
import com.media360sync.app.ui.components.ScreenHeader
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt

enum class LibTab(val label: String, val icon: ImageVector) {
    VIDEOS("Videos", Icons.Rounded.Movie),
    MUSIC("Music", Icons.Rounded.MusicNote),
}

@Composable
fun LibraryScreen(vm: MainViewModel, padding: PaddingValues) {
    val all by vm.history.collectAsStateWithLifecycle()
    val ps by vm.player.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(LibTab.VIDEOS) }

    val videos = all.filterNot { it.isAudio }
    val music = all.filter { it.isAudio }
    val list = if (tab == LibTab.MUSIC) music else videos

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding()
        ),
    ) {
        item {
            ScreenHeader("Library", "Your media", "${videos.size} videos • ${music.size} songs")
            Spacer(Modifier.height(18.dp))
            TabSwitcher(tab, videos.size, music.size) { tab = it }
            Spacer(Modifier.height(16.dp))
            if (list.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    GradientButton("Play all", Icons.Rounded.PlayArrow, { vm.playAll(list, shuffle = false) }, Modifier.weight(1f))
                    GlassButton("Shuffle", Icons.Rounded.Shuffle, { vm.playAll(list, shuffle = true) }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        if (list.isEmpty()) item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    if (tab == LibTab.MUSIC) "No songs yet" else "No videos yet",
                    color = Palette.TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (tab == LibTab.MUSIC)
                        "On the Kick tab choose “Audio only”, share a link and tap the ball. Songs appear here."
                    else "Share a link from YouTube, Instagram or TikTok, then tap the ball. Videos appear here.",
                    color = Palette.TextMid, lineHeight = 20.sp
                )
            }
        }

        itemsIndexed(list, key = { _, it -> it.id }) { i, item ->
            val isCurrent = ps.current?.id == item.id.toString()
            MediaRow(
                item, isCurrent, ps.isPlaying,
                onPlay = { vm.play(list, i) },
                onShare = { share(ctx, item) },
                onOpenWith = { openWith(ctx, item) },
                onRemove = { vm.removeHistory(item.id) },
            )
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun TabSwitcher(selected: LibTab, videoCount: Int, musicCount: Int, onSelect: (LibTab) -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Palette.Ink.copy(alpha = 0.06f))
            .border(1.dp, Palette.Ink.copy(alpha = 0.1f), shape).padding(4.dp)
    ) {
        LibTab.entries.forEach { t ->
            val on = t == selected
            val tint by animateColorAsState(if (on) Color.White else Palette.TextMid, label = "tab")
            Row(
                Modifier.weight(1f).clip(shape)
                    .background(if (on) BrandBrush else SolidColor(Color.Transparent))
                    .clickable { onSelect(t) }.padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(t.icon, null, tint = tint, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                val count = if (t == LibTab.MUSIC) musicCount else videoCount
                Text("${t.label}  $count", color = tint, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun MediaRow(
    item: HistoryItem, isCurrent: Boolean, playing: Boolean,
    onPlay: () -> Unit, onShare: () -> Unit, onOpenWith: () -> Unit, onRemove: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (isCurrent) Palette.Violet.copy(alpha = 0.12f) else Palette.GlassTop)
            .border(1.dp, if (isCurrent) Palette.Violet.copy(alpha = 0.45f) else Palette.Ink.copy(alpha = 0.08f), shape)
            .clickable(onClick = onPlay).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MediaThumb(
            item.uri, item.isAudio,
            Modifier.size(width = if (item.isAudio) 54.dp else 96.dp, height = 54.dp), corner = 12.dp
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.title, color = if (isCurrent) Palette.Violet else Palette.TextHi,
                fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${item.platform} • ${Fmt.bytes(item.size)}",
                color = Palette.TextLow, fontSize = 12.sp, maxLines = 1
            )
        }
        if (isCurrent) { Spacer(Modifier.width(6.dp)); EqualizerBars(playing) }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More", tint = Palette.TextLow) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Share") }, leadingIcon = { Icon(Icons.Rounded.Share, null) },
                    onClick = { menu = false; onShare() })
                DropdownMenuItem(
                    text = { Text("Open with…") }, leadingIcon = { Icon(Icons.Rounded.OpenInNew, null) },
                    onClick = { menu = false; onOpenWith() })
                DropdownMenuItem(
                    text = { Text("Remove from library") }, leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null) },
                    onClick = { menu = false; onRemove() })
            }
        }
    }
}

private fun openWith(ctx: Context, item: HistoryItem) {
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.uri), item.mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        ctx.startActivity(Intent.createChooser(intent, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: ActivityNotFoundException) { }
}

private fun share(ctx: Context, item: HistoryItem) {
    val send = Intent(Intent.ACTION_SEND).setType(item.mime)
        .putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
