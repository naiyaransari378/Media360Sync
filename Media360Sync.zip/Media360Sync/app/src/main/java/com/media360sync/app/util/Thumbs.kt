package com.media360sync.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Cover art: the embedded thumbnail (we embed it on download), or a video frame. */
object Thumbs {
    private val cache = LruCache<String, ImageBitmap>(48)

    fun peek(uri: String): ImageBitmap? = cache.get(uri)

    suspend fun load(ctx: Context, uri: String, isAudio: Boolean): ImageBitmap? {
        cache.get(uri)?.let { return it }
        return withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, Uri.parse(uri))
                val raw: Bitmap? = r.embeddedPicture?.let { decodeSampled(it, 512) }
                    ?: if (!isAudio) r.getFrameAtTime(2_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) else null
                raw?.let { scaleDown(it, 480) }?.asImageBitmap()?.also { cache.put(uri, it) }
            } catch (e: Exception) {
                null
            } finally {
                runCatching { r.release() }
            }
        }
    }

    private fun decodeSampled(bytes: ByteArray, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun scaleDown(b: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(b.width, b.height)
        if (longest <= maxSide) return b
        val f = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }
}

@Composable
fun rememberThumb(uri: String?, isAudio: Boolean): ImageBitmap? {
    val ctx = LocalContext.current
    return produceState(initialValue = uri?.let { Thumbs.peek(it) }, uri) {
        value = if (uri.isNullOrEmpty()) null else Thumbs.load(ctx, uri, isAudio)
    }.value
}
