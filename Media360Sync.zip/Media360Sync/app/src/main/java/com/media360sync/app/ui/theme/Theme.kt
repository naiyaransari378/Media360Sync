package com.media360sync.app.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Colours that change between Day and Night. */
@Immutable
data class AppColors(
    val isDark: Boolean,
    val bg: Color,        // screen background
    val panel: Color,     // solid surfaces (nav bar)
    val textHi: Color,
    val textMid: Color,
    val textLow: Color,
    val label: Color,
    val ink: Color,       // tint for translucent overlays, borders, tracks
    val field: Color,     // text-field fill
    val glassTop: Color,
    val glassBottom: Color,
    val glassEdge: Color,
    val shadow: Color,
)

val NightColors = AppColors(
    isDark = true,
    bg = Color(0xFF07060F), panel = Color(0xFF14122A),
    textHi = Color(0xFFF5F5FF), textMid = Color(0xFFB9BCDC), textLow = Color(0xFF7D81A8), label = Color(0xFF9AA3CF),
    ink = Color.White, field = Color(0x40000000),
    glassTop = Color.White.copy(alpha = 0.085f), glassBottom = Color.White.copy(alpha = 0.025f),
    glassEdge = Color.White.copy(alpha = 0.26f), shadow = Color.Black.copy(alpha = 0.55f),
)

val DayColors = AppColors(
    isDark = false,
    bg = Color(0xFFEFEEFA), panel = Color(0xFFFFFFFF),
    textHi = Color(0xFF15132B), textMid = Color(0xFF474A6B), textLow = Color(0xFF7B7FA0), label = Color(0xFF6A6EA0),
    ink = Color(0xFF1B1840), field = Color(0xB3FFFFFF),
    glassTop = Color.White.copy(alpha = 0.78f), glassBottom = Color.White.copy(alpha = 0.5f),
    glassEdge = Color.White, shadow = Color(0xFF1B1840).copy(alpha = 0.25f),
)

private val LocalAppColors = staticCompositionLocalOf { NightColors }

object Palette {
    // Brand colours — identical in Day and Night
    val Violet = Color(0xFF8B5CF6)
    val Indigo = Color(0xFF6366F1)
    val Sky = Color(0xFF60A5FA)
    val Cyan = Color(0xFF38C9E0)
    val Mint = Color(0xFF22C55E)
    val Rose = Color(0xFFF43F5E)
    val Amber = Color(0xFFF59E0B)

    // Theme colours
    val isDark: Boolean @Composable @ReadOnlyComposable get() = LocalAppColors.current.isDark
    val Bg: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.bg
    val Panel: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.panel
    val TextHi: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.textHi
    val TextMid: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.textMid
    val TextLow: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.textLow
    val Label: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.label
    val Ink: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.ink
    val Field: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.field
    val GlassTop: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.glassTop
    val GlassBottom: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.glassBottom
    val GlassEdge: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.glassEdge
    val Shadow: Color @Composable @ReadOnlyComposable get() = LocalAppColors.current.shadow
}

val BrandBrush = Brush.linearGradient(listOf(Palette.Violet, Palette.Sky, Palette.Cyan))

/** Smoothly fades every colour when switching Day ⇄ Night. */
@Composable
private fun animate(target: AppColors): AppColors {
    val spec = tween<Color>(450)
    val bg by animateColorAsState(target.bg, spec, label = "bg")
    val panel by animateColorAsState(target.panel, spec, label = "panel")
    val hi by animateColorAsState(target.textHi, spec, label = "hi")
    val mid by animateColorAsState(target.textMid, spec, label = "mid")
    val low by animateColorAsState(target.textLow, spec, label = "low")
    val label by animateColorAsState(target.label, spec, label = "label")
    val ink by animateColorAsState(target.ink, spec, label = "ink")
    val field by animateColorAsState(target.field, spec, label = "field")
    val gt by animateColorAsState(target.glassTop, spec, label = "gt")
    val gb by animateColorAsState(target.glassBottom, spec, label = "gb")
    val ge by animateColorAsState(target.glassEdge, spec, label = "ge")
    val sh by animateColorAsState(target.shadow, spec, label = "sh")
    return AppColors(target.isDark, bg, panel, hi, mid, low, label, ink, field, gt, gb, ge, sh)
}

@Composable
fun Media360Theme(dark: Boolean, content: @Composable () -> Unit) {
    val colors = animate(if (dark) NightColors else DayColors)
    val scheme = if (dark) darkColorScheme(
        primary = Palette.Violet, secondary = Palette.Sky, tertiary = Palette.Cyan,
        background = colors.bg, surface = colors.panel, error = Palette.Rose,
        onPrimary = Color.White, onBackground = colors.textHi, onSurface = colors.textHi,
    ) else lightColorScheme(
        primary = Palette.Violet, secondary = Palette.Sky, tertiary = Palette.Cyan,
        background = colors.bg, surface = colors.panel, error = Palette.Rose,
        onPrimary = Color.White, onBackground = colors.textHi, onSurface = colors.textHi,
    )
    CompositionLocalProvider(LocalAppColors provides colors) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}
