package com.media360sync.app

import android.app.Application
import com.media360sync.app.engine.EngineManager
import com.media360sync.app.util.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class App : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
        EngineManager.initialize(this, appScope)
    }
}
