package com.media360sync.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.activity.compose.BackHandler
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.SportsSoccer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.media360sync.app.ui.components.AuroraBackground
import com.media360sync.app.ui.components.MiniPlayer
import com.media360sync.app.ui.screens.NowPlayingScreen
import com.media360sync.app.ui.screens.EngineScreen
import com.media360sync.app.ui.screens.HomeScreen
import com.media360sync.app.ui.screens.LibraryScreen
import com.media360sync.app.ui.screens.SettingsScreen
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Kick", Icons.Rounded.SportsSoccer),
    LIBRARY("Library", Icons.Rounded.VideoLibrary),
    ENGINE("Engine", Icons.Rounded.Memory),
    SETTINGS("Settings", Icons.Rounded.Tune),
}

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    LaunchedEffect(vm.homeRequests) { if (vm.homeRequests > 0) tab = Tab.HOME }

    val ps by vm.player.state.collectAsStateWithLifecycle()
    val hasMedia = ps.current != null
    val fullPlayer = vm.playerExpanded && hasMedia
    BackHandler(enabled = fullPlayer) { if (vm.videoFullscreen) vm.videoFullscreen = false else vm.collapsePlayer() }

    AuroraBackground {
        val bars = WindowInsets.systemBars.asPaddingValues()
        val content = PaddingValues(
            top = bars.calculateTopPadding() + 16.dp,
            bottom = bars.calculateBottomPadding() + 112.dp + if (hasMedia) 76.dp else 0.dp,
        )
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "tabs",
        ) { t ->
            when (t) {
                Tab.HOME -> HomeScreen(vm, content)
                Tab.LIBRARY -> LibraryScreen(vm, content)
                Tab.ENGINE -> EngineScreen(vm, content)
                Tab.SETTINGS -> SettingsScreen(vm, content)
            }
        }
        AnimatedVisibility(
            visible = hasMedia && !vm.playerExpanded,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = bars.calculateBottomPadding() + 92.dp, start = 18.dp, end = 18.dp),
        ) {
            MiniPlayer(
                ps,
                onOpen = vm::expandPlayer,
                onToggle = vm.player::togglePlay,
                onNext = vm.player::next,
                onClose = vm::closePlayer,
            )
        }

        val dark = Palette.isDark
        GlassNavBar(
            selected = tab, onSelect = { tab = it },
            dark = dark, onToggleTheme = { vm.toggleTheme(dark) },
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = bars.calculateBottomPadding() + 14.dp, start = 18.dp, end = 18.dp)
        )

        // Full "Now playing" screen slides up over everything
        AnimatedVisibility(
            visible = fullPlayer,
            enter = slideInVertically(tween(320)) { it },
            exit = slideOutVertically(tween(260)) { it },
        ) { NowPlayingScreen(vm) }
    }
}

@Composable
private fun GlassNavBar(
    selected: Tab, onSelect: (Tab) -> Unit,
    dark: Boolean, onToggleTheme: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier.fillMaxWidth().height(68.dp).clip(shape)
            .background(Palette.Panel.copy(alpha = 0.88f))
            .border(1.dp, Palette.Ink.copy(alpha = 0.12f), shape)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Tab.entries.forEach { t ->
            val on = t == selected
            val pill = RoundedCornerShape(50)
            Row(
                Modifier.clip(pill)
                    .background(if (on) BrandBrush else SolidColor(Color.Transparent))
                    .clickable { onSelect(t) }
                    .padding(horizontal = if (on) 16.dp else 12.dp, vertical = 12.dp)
                    .animateContentSize(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(t.icon, t.label, tint = if (on) Color.White else Palette.TextLow, modifier = Modifier.size(22.dp))
                AnimatedVisibility(on) {
                    Row {
                        Spacer(Modifier.width(8.dp))
                        Text(t.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
        ThemeToggle(dark, onToggleTheme)
    }
}

/** Sun in Night mode (tap for Day), moon in Day mode (tap for Night). Spins as it swaps. */
@Composable
private fun ThemeToggle(dark: Boolean, onToggle: () -> Unit) {
    val spin by animateFloatAsState(
        if (dark) 0f else 360f, spring(dampingRatio = 0.6f, stiffness = 200f), label = "themeSpin"
    )
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .background(if (dark) Palette.Amber.copy(alpha = 0.16f) else Palette.Violet.copy(alpha = 0.14f))
            .border(1.dp, if (dark) Palette.Amber.copy(alpha = 0.5f) else Palette.Violet.copy(alpha = 0.45f), CircleShape)
            .clickable(onClick = onToggle),
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = dark,
            transitionSpec = { (fadeIn(tween(200)) + scaleIn(tween(250))) togetherWith (fadeOut(tween(150)) + scaleOut(tween(150))) },
            label = "themeIcon",
        ) { isDark ->
            Icon(
                if (isDark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                contentDescription = if (isDark) "Switch to day mode" else "Switch to night mode",
                tint = if (isDark) Palette.Amber else Palette.Violet,
                modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = spin },
            )
        }
    }
}
