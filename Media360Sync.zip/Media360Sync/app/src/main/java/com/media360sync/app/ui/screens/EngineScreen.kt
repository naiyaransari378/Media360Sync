package com.media360sync.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.data.EngineChannel
import com.media360sync.app.engine.EngineStatus
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.components.ChoiceChips
import com.media360sync.app.ui.components.GlassButton
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.GradientButton
import com.media360sync.app.ui.components.InfoRow
import com.media360sync.app.ui.components.ScreenHeader
import com.media360sync.app.ui.components.SectionLabel
import com.media360sync.app.ui.components.StatusPill
import com.media360sync.app.ui.components.SwitchRow
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt
import com.media360sync.app.util.Platform

@Composable
fun EngineScreen(vm: MainViewModel, padding: PaddingValues) {
    val engine by vm.engine.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val updating = engine.status == EngineStatus.UPDATING

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(padding).padding(horizontal = 20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                ScreenHeader(
                    "Media engine", "Seal-style core for serious downloads.",
                    "Control center for yt-dlp updates, extractor health and platform readiness."
                )
            }
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(84.dp).clip(CircleShape).background(BrandBrush),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Memory, null, tint = Color.White, modifier = Modifier.size(40.dp)) }
        }
        Spacer(Modifier.height(24.dp))

        GlassCard(Modifier.fillMaxWidth(), corner = 32.dp, padding = 24.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SectionLabel("Native engine")
                    Spacer(Modifier.height(6.dp))
                    Text(
                        when (engine.status) {
                            EngineStatus.READY -> "Ready"; EngineStatus.UPDATING -> "Updating"
                            EngineStatus.STARTING -> "Starting"; EngineStatus.ERROR -> "Offline"
                        },
                        color = Palette.TextHi, fontSize = 30.sp, fontWeight = FontWeight.Black
                    )
                }
                StatusPill(
                    if (engine.status == EngineStatus.ERROR) "OFFLINE" else "ONLINE",
                    if (engine.status == EngineStatus.ERROR) Palette.Rose else Palette.Mint
                )
            }
            Spacer(Modifier.height(18.dp))
            GlassCard(Modifier.fillMaxWidth(), corner = 26.dp, padding = 16.dp) {
                InfoRow("Engine", "android-yt-dlp")
                InfoRow("yt-dlp version", engine.version ?: "—")
                InfoRow("Last update", Fmt.dateTime(engine.lastUpdate))
                InfoRow("Channel", settings.channel.label)
                InfoRow("Platform", "Android native bridge")
            }
            if (updating) {
                Spacer(Modifier.height(16.dp))
                LinearProgressIndicator(
                    Modifier.fillMaxWidth(), color = Palette.Sky, trackColor = Color.White.copy(alpha = 0.08f)
                )
            }
            engine.message?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Palette.TextMid, fontSize = 13.sp)
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassButton(
                    "Stable", Icons.Rounded.Sync, { vm.updateEngine(EngineChannel.STABLE) },
                    Modifier.weight(1f), enabled = !updating
                )
                GradientButton(
                    "Nightly", Icons.Rounded.Bolt, { vm.updateEngine(EngineChannel.NIGHTLY) },
                    Modifier.weight(1f), enabled = !updating
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Auto-update")
            Spacer(Modifier.height(4.dp))
            SwitchRow(
                "Update engine automatically",
                "Checks once a day on Wi-Fi. Sites change often — this keeps downloads working.",
                settings.autoUpdate
            ) { on -> vm.updateSettings { it.copy(autoUpdate = on) } }
            Spacer(Modifier.height(8.dp))
            Text("Channel", color = Palette.TextHi, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            ChoiceChips(EngineChannel.entries.map { it.label }, settings.channel.ordinal, { i ->
                vm.updateSettings { it.copy(channel = EngineChannel.entries[i]) }
            })
            Spacer(Modifier.height(6.dp))
            Text(
                "Nightly gets extractor fixes first. Stable is tested longer.",
                color = Palette.TextLow, fontSize = 13.sp
            )
        }

        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Extractor readiness")
            Spacer(Modifier.height(8.dp))
            val ok = engine.status == EngineStatus.READY || updating
            Platform.entries.filter { it != Platform.OTHER }.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(Color(p.color)))
                    Spacer(Modifier.width(12.dp))
                    Text(p.label, color = Palette.TextHi, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Icon(
                        Icons.Rounded.CheckCircle, null,
                        tint = if (ok) Palette.Mint else Palette.TextLow, modifier = Modifier.size(20.dp)
                    )
                }
            }
            Text("+ 1,000 more sites supported by yt-dlp", color = Palette.TextLow, fontSize = 13.sp)
        }
    }
}
