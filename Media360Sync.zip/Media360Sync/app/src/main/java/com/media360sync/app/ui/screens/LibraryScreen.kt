package com.media360sync.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.data.HistoryItem
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.ScreenHeader
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt

@Composable
fun LibraryScreen(vm: MainViewModel, padding: PaddingValues) {
    val items by vm.history.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding()
        ),
    ) {
        item {
            Row(verticalAlignment = Alignment.Bottom) {
                Box(Modifier.weight(1f)) {
                    ScreenHeader("Library", "Your downloads", "${items.size} saved • Movies & Music/Media360Sync")
                }
                if (items.isNotEmpty()) Text(
                    "Clear", color = Palette.TextLow, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.clearHistory() }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
        }
        if (items.isEmpty()) item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Nothing here yet", color = Palette.TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Open YouTube, Instagram or TikTok, tap Share, choose Media360Sync, then tap the ball.",
                    color = Palette.TextMid, lineHeight = 20.sp
                )
            }
        }
        items(items, key = { it.id }) { item ->
            HistoryRow(item, onOpen = { open(ctx, item) }, onShare = { share(ctx, item) }, onDelete = { vm.removeHistory(item.id) })
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun HistoryRow(item: HistoryItem, onOpen: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth().clickable(onClick = onOpen), corner = 22.dp, padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(BrandBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (item.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.Movie, null, tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title, color = Palette.TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "${item.platform} • ${Fmt.bytes(item.size)} • ${Fmt.dateTime(item.time)}",
                    color = Palette.TextLow, fontSize = 12.sp, maxLines = 1
                )
            }
            IconButton(onClick = onShare) { Icon(Icons.Rounded.Share, "Share", tint = Palette.Sky) }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.DeleteOutline, "Remove", tint = Palette.TextLow) }
        }
    }
}

private fun open(ctx: Context, item: HistoryItem) {
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.uri), item.mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(intent) } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can play this file", Toast.LENGTH_SHORT).show()
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "The file was moved or deleted", Toast.LENGTH_SHORT).show()
    }
}

private fun share(ctx: Context, item: HistoryItem) {
    val send = Intent(Intent.ACTION_SEND).setType(item.mime)
        .putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
