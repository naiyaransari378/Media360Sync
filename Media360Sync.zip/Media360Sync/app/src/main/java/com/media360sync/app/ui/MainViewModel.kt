package com.media360sync.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.media360sync.app.data.AppSettings
import com.media360sync.app.data.EngineChannel
import com.media360sync.app.data.HistoryItem
import com.media360sync.app.data.HistoryRepository
import com.media360sync.app.data.SettingsRepository
import com.media360sync.app.download.DownloadWorker
import com.media360sync.app.engine.EngineManager
import com.media360sync.app.engine.UpdateWorker
import com.media360sync.app.util.UrlUtils
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class Phase { IDLE, QUEUED, RUNNING, DONE, FAILED }

data class DownloadUi(
    val phase: Phase = Phase.IDLE,
    val progress: Float? = null,
    val eta: Long = 0,
    val line: String = "",
    val platform: String = "",
    val title: String = "",
    val error: String? = null,
    val waiting: Int = 0,
    val workId: UUID? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    private val wm = WorkManager.getInstance(app)
    private val historyRepo = HistoryRepository.get(app)

    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val history: StateFlow<List<HistoryItem>> = historyRepo.items
    val engine = EngineManager.state

    var url by mutableStateOf(""); private set
    var clipboardSuggestion by mutableStateOf<String?>(null); private set
    var homeRequests by mutableIntStateOf(0); private set

    private var dismissedClip: String? = null
    private val lastWorkId = MutableStateFlow<UUID?>(null)
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val download: StateFlow<DownloadUi> =
        combine(wm.getWorkInfosByTagFlow(DownloadWorker.TAG), lastWorkId) { infos, last ->
            val running = infos.firstOrNull { it.state == WorkInfo.State.RUNNING }
            val waiting = infos.count { it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.BLOCKED }
            when {
                running != null -> {
                    val p = running.progress
                    DownloadUi(
                        Phase.RUNNING,
                        progress = p.getFloat(DownloadWorker.KEY_PROGRESS, -1f).takeIf { it >= 0f },
                        eta = p.getLong(DownloadWorker.KEY_ETA, 0),
                        line = p.getString(DownloadWorker.KEY_LINE).orEmpty(),
                        platform = p.getString(DownloadWorker.KEY_PLATFORM).orEmpty(),
                        waiting = waiting, workId = running.id,
                    )
                }
                waiting > 0 -> DownloadUi(Phase.QUEUED, waiting = waiting)
                else -> {
                    val info = infos.firstOrNull { it.id == last }
                    when (info?.state) {
                        WorkInfo.State.SUCCEEDED -> DownloadUi(
                            Phase.DONE, title = info.outputData.getString(DownloadWorker.KEY_TITLE).orEmpty()
                        )
                        WorkInfo.State.FAILED, WorkInfo.State.CANCELLED -> DownloadUi(
                            Phase.FAILED,
                            error = info.outputData.getString(DownloadWorker.KEY_ERROR) ?: "Download cancelled"
                        )
                        else -> DownloadUi()
                    }
                }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DownloadUi())

    fun onUrlChange(value: String) { url = value }

    fun startDownload() {
        val link = UrlUtils.extractUrl(url)
        if (link == null) {
            _messages.tryEmit(if (url.isBlank()) "Paste or share a link first" else "That doesn't look like a link")
            return
        }
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(DownloadWorker.input(link))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .addTag(DownloadWorker.TAG)
            .build()
        wm.enqueueUniqueWork(DownloadWorker.QUEUE, ExistingWorkPolicy.APPEND_OR_REPLACE, req)
        lastWorkId.value = req.id
        if (download.value.phase == Phase.RUNNING) _messages.tryEmit("Added to queue")
        url = ""
        clipboardSuggestion = null
    }

    fun cancelDownload() {
        val id = download.value.workId ?: return
        runCatching { YoutubeDL.getInstance().destroyProcessById(id.toString()) }
        wm.cancelWorkById(id)
    }

    fun onSharedText(text: String?) {
        val link = UrlUtils.extractUrl(text) ?: return
        url = link
        homeRequests++
        viewModelScope.launch {
            if (repo.settings.first().autoDownloadOnShare) startDownload()
        }
    }

    fun onClipboard(text: String?) {
        val link = UrlUtils.extractUrl(text) ?: return
        if (link == url || link == dismissedClip) return
        clipboardSuggestion = link
    }

    fun useClipboard() {
        clipboardSuggestion?.let { url = it }
        dismissedClip = clipboardSuggestion
        clipboardSuggestion = null
    }

    fun dismissClipboard() { dismissedClip = clipboardSuggestion; clipboardSuggestion = null }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val old = settings.value
        val new = transform(old)
        viewModelScope.launch {
            repo.save(new)
            if (new.autoUpdate != old.autoUpdate) {
                if (new.autoUpdate) UpdateWorker.schedule(getApplication()) else UpdateWorker.cancel(getApplication())
            }
        }
    }

    fun updateEngine(channel: EngineChannel) {
        updateSettings { it.copy(channel = channel) }
        viewModelScope.launch { _messages.emit(EngineManager.update(getApplication(), channel)) }
    }

    fun removeHistory(id: Long) = historyRepo.remove(id)
    fun clearHistory() = historyRepo.clear()
}
