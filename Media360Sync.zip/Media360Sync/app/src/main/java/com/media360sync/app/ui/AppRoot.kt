package com.media360sync.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.SportsSoccer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.media360sync.app.ui.components.AuroraBackground
import com.media360sync.app.ui.screens.EngineScreen
import com.media360sync.app.ui.screens.HomeScreen
import com.media360sync.app.ui.screens.LibraryScreen
import com.media360sync.app.ui.screens.SettingsScreen
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Kick", Icons.Rounded.SportsSoccer),
    LIBRARY("Library", Icons.Rounded.VideoLibrary),
    ENGINE("Engine", Icons.Rounded.Memory),
    SETTINGS("Settings", Icons.Rounded.Tune),
}

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    LaunchedEffect(vm.homeRequests) { if (vm.homeRequests > 0) tab = Tab.HOME }

    AuroraBackground {
        val bars = WindowInsets.systemBars.asPaddingValues()
        val content = PaddingValues(
            top = bars.calculateTopPadding() + 16.dp,
            bottom = bars.calculateBottomPadding() + 112.dp,
        )
        AnimatedContent(
            targetState = tab,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
            label = "tabs",
        ) { t ->
            when (t) {
                Tab.HOME -> HomeScreen(vm, content)
                Tab.LIBRARY -> LibraryScreen(vm, content)
                Tab.ENGINE -> EngineScreen(vm, content)
                Tab.SETTINGS -> SettingsScreen(vm, content)
            }
        }
        GlassNavBar(
            selected = tab, onSelect = { tab = it },
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = bars.calculateBottomPadding() + 14.dp, start = 18.dp, end = 18.dp)
        )
    }
}

@Composable
private fun GlassNavBar(selected: Tab, onSelect: (Tab) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier.fillMaxWidth().height(68.dp).clip(shape)
            .background(Palette.Panel.copy(alpha = 0.88f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Tab.entries.forEach { t ->
            val on = t == selected
            val pill = RoundedCornerShape(50)
            Row(
                Modifier.clip(pill)
                    .background(if (on) BrandBrush else SolidColor(Color.Transparent))
                    .clickable { onSelect(t) }
                    .padding(horizontal = if (on) 18.dp else 14.dp, vertical = 12.dp)
                    .animateContentSize(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(t.icon, t.label, tint = if (on) Color.White else Palette.TextLow, modifier = Modifier.size(22.dp))
                AnimatedVisibility(on) {
                    Row {
                        Spacer(Modifier.width(8.dp))
                        Text(t.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
