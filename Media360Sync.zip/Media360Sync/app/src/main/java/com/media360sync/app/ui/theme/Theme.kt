package com.media360sync.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Palette {
    val Bg = Color(0xFF07060F)
    val Panel = Color(0xFF14122A)
    val Violet = Color(0xFF8B5CF6)
    val Indigo = Color(0xFF6366F1)
    val Sky = Color(0xFF60A5FA)
    val Cyan = Color(0xFF5EE7F7)
    val Mint = Color(0xFF4ADE80)
    val Rose = Color(0xFFFB7185)
    val Amber = Color(0xFFFBBF24)
    val TextHi = Color(0xFFF5F5FF)
    val TextMid = Color(0xFFB9BCDC)
    val TextLow = Color(0xFF7D81A8)
    val Label = Color(0xFF9AA3CF)
}

val BrandBrush = Brush.linearGradient(listOf(Palette.Violet, Palette.Sky, Palette.Cyan))

@Composable
fun Media360Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Violet, secondary = Palette.Sky, tertiary = Palette.Cyan,
            background = Palette.Bg, surface = Palette.Panel, error = Palette.Rose,
            onPrimary = Color.White, onBackground = Palette.TextHi, onSurface = Palette.TextHi,
        ),
        typography = Typography(),
        content = content,
    )
}
