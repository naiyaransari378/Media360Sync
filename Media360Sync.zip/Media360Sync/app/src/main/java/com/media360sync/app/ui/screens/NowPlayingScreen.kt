package com.media360sync.app.ui.screens

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.media360sync.app.playback.PlayerState
import com.media360sync.app.playback.QueueEntry
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.components.EqualizerBars
import com.media360sync.app.ui.components.MediaThumb
import com.media360sync.app.ui.components.SectionLabel
import com.media360sync.app.ui.components.VideoSurface
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(vm: MainViewModel) {
    val ps by vm.player.state.collectAsStateWithLifecycle()
    val current = ps.current ?: return

    if (vm.videoFullscreen && current.isVideo) {
        FullscreenVideo(vm, ps)
        return
    }

    val bars = WindowInsets.systemBars.asPaddingValues()
    Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        Box(
            Modifier.fillMaxWidth().height(460.dp)
                .background(Brush.verticalGradient(listOf(Palette.Violet.copy(alpha = 0.32f), Color.Transparent)))
        )
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp, end = 20.dp,
                top = bars.calculateTopPadding() + 4.dp, bottom = bars.calculateBottomPadding() + 24.dp
            ),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = vm::collapsePlayer) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Minimize player", tint = Palette.TextHi, modifier = Modifier.size(32.dp))
                    }
                    Text(
                        if (current.isVideo) "Now playing · Video" else "Now playing",
                        color = Palette.TextMid, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(48.dp))
                }
                Spacer(Modifier.height(16.dp))
            }

            item {
                if (current.isVideo) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(20.dp)).background(Color.Black)
                    ) {
                        VideoSurface(vm.player.controller, Modifier.fillMaxSize())
                        IconButton(
                            onClick = { vm.videoFullscreen = true },
                            modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                                .clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))
                        ) { Icon(Icons.Rounded.Fullscreen, "Full screen", tint = Color.White) }
                    }
                } else {
                    val scale by animateFloatAsState(
                        if (ps.isPlaying) 1f else 0.9f, spring(dampingRatio = 0.6f, stiffness = 180f), label = "art"
                    )
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        MediaThumb(
                            current.uri, isAudio = true,
                            modifier = Modifier.fillMaxWidth(0.86f).aspectRatio(1f)
                                .graphicsLayer { scaleX = scale; scaleY = scale },
                            corner = 28.dp, iconSize = 96.dp,
                        )
                    }
                }
                Spacer(Modifier.height(28.dp))
            }

            item {
                Text(
                    current.title, color = Palette.TextHi, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 28.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(current.subtitle, color = Palette.TextMid, fontSize = 15.sp)
                Spacer(Modifier.height(16.dp))
                SeekBar(ps, vm.player::seekTo, light = false)
                Spacer(Modifier.height(8.dp))
                Controls(vm, ps)
                Spacer(Modifier.height(28.dp))
            }

            if (ps.queue.size > 1) {
                item {
                    SectionLabel("Queue • ${ps.queue.size}")
                    Spacer(Modifier.height(8.dp))
                }
                itemsIndexed(ps.queue, key = { i, e -> "${e.id}-$i" }) { i, entry ->
                    QueueRow(entry, isCurrent = i == ps.index, playing = ps.isPlaying) { vm.player.skipTo(i) }
                }
            }
        }
    }
}

@Composable
private fun SeekBar(ps: PlayerState, onSeek: (Long) -> Unit, light: Boolean) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = ps.durationMs.coerceAtLeast(1)
    val value = dragging ?: ps.progress
    val textColor = if (light) Color.White.copy(alpha = 0.85f) else Palette.TextLow
    Column {
        Slider(
            value = value,
            onValueChange = { dragging = it },
            onValueChangeFinished = { dragging?.let { onSeek((it * duration).toLong()) }; dragging = null },
            colors = SliderDefaults.colors(
                thumbColor = if (light) Color.White else Palette.Violet,
                activeTrackColor = if (light) Color.White else Palette.Violet,
                inactiveTrackColor = if (light) Color.White.copy(alpha = 0.25f) else Palette.Ink.copy(alpha = 0.15f),
            ),
        )
        Row {
            Text(Fmt.clock(((dragging ?: ps.progress) * ps.durationMs).toLong()), color = textColor, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text(Fmt.clock(ps.durationMs), color = textColor, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Controls(vm: MainViewModel, ps: PlayerState) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = vm.player::toggleShuffle) {
            Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (ps.shuffle) Palette.Violet else Palette.TextLow)
        }
        IconButton(onClick = vm.player::previous, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Palette.TextHi, modifier = Modifier.size(38.dp))
        }
        PlayButton(ps, size = 76, onClick = vm.player::togglePlay)
        IconButton(onClick = vm.player::next, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Rounded.SkipNext, "Next", tint = Palette.TextHi, modifier = Modifier.size(38.dp))
        }
        IconButton(onClick = vm.player::cycleRepeat) {
            Icon(
                if (ps.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                "Repeat", tint = if (ps.repeatMode == Player.REPEAT_MODE_OFF) Palette.TextLow else Palette.Violet
            )
        }
    }
}

@Composable
private fun PlayButton(ps: PlayerState, size: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(BrandBrush).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (ps.isBuffering) CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size((size * 0.4f).dp))
        else Icon(
            if (ps.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            if (ps.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size((size * 0.52f).dp)
        )
    }
}

@Composable
private fun QueueRow(entry: QueueEntry, isCurrent: Boolean, playing: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(if (isCurrent) Palette.Violet.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MediaThumb(
            entry.uri, !entry.isVideo,
            Modifier.size(width = if (entry.isVideo) 76.dp else 44.dp, height = 44.dp), corner = 10.dp, iconSize = 18.dp
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.title, color = if (isCurrent) Palette.Violet else Palette.TextHi,
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(entry.subtitle, color = Palette.TextLow, fontSize = 12.sp, maxLines = 1)
        }
        if (isCurrent) EqualizerBars(playing)
    }
}

/** Landscape, edge-to-edge video. Tap to show/hide controls. */
@Composable
private fun FullscreenVideo(vm: MainViewModel, ps: PlayerState) {
    val activity = LocalContext.current as? Activity
    DisposableEffect(Unit) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val window = activity?.window
        val insets = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        insets?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insets?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            insets?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    BackHandler { vm.videoFullscreen = false }

    var showControls by remember { mutableStateOf(true) }
    LaunchedEffect(showControls, ps.isPlaying) {
        if (showControls && ps.isPlaying) { delay(3000); showControls = false }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                showControls = !showControls
            }
    ) {
        VideoSurface(vm.player.controller, Modifier.fillMaxSize())
        AnimatedVisibility(showControls, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f))) {
                Row(Modifier.align(Alignment.TopStart).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.videoFullscreen = false }) {
                        Icon(Icons.Rounded.FullscreenExit, "Exit full screen", tint = Color.White)
                    }
                    Text(
                        ps.current?.title.orEmpty(), color = Color.White, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = vm.player::previous, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(40.dp))
                    }
                    PlayButton(ps, size = 72, onClick = vm.player::togglePlay)
                    IconButton(onClick = vm.player::next, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(40.dp))
                    }
                }
                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
                    SeekBar(ps, vm.player::seekTo, light = true)
                }
            }
        }
    }
}
