package com.media360sync.app.ui.components

import android.graphics.Color as AndroidColor
import androidx.annotation.OptIn
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.media360sync.app.playback.PlayerState
import com.media360sync.app.ui.theme.BrandBrush
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.rememberThumb

/** Cover art or video frame, with a gradient + icon fallback. */
@Composable
fun MediaThumb(uri: String?, isAudio: Boolean, modifier: Modifier, corner: Dp = 14.dp, iconSize: Dp = 22.dp) {
    val img = rememberThumb(uri, isAudio)
    Box(modifier.clip(RoundedCornerShape(corner)).background(BrandBrush), contentAlignment = Alignment.Center) {
        if (img != null) {
            Image(img, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(if (isAudio) Icons.Rounded.MusicNote else Icons.Rounded.Movie, null, tint = Color.White, modifier = Modifier.size(iconSize))
        }
    }
}

/** ExoPlayer video output. Releasing it does not stop playback — audio carries on. */
@OptIn(UnstableApi::class)
@Composable
fun VideoSurface(player: Player?, modifier: Modifier = Modifier) {
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setShutterBackgroundColor(AndroidColor.BLACK)
                keepScreenOn = true
            }
        },
        update = { it.player = player },
        onRelease = { it.player = null },
        modifier = modifier,
    )
}

/** Three bouncing bars marking the song that is playing. */
@Composable
fun EqualizerBars(playing: Boolean, color: Color = Palette.Violet, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(420), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0.25f, infiniteRepeatable(tween(530), RepeatMode.Reverse), label = "b")
    val c by t.animateFloat(0.5f, 0.9f, infiniteRepeatable(tween(360), RepeatMode.Reverse), label = "c")
    val heights = if (playing) listOf(a, b, c) else listOf(0.35f, 0.6f, 0.45f)
    Row(modifier.size(18.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        heights.forEach { h ->
            Box(Modifier.width(4.dp).fillMaxHeight(h).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

/** Compact player that floats above the bottom bar. Tap to open the full player. */
@Composable
fun MiniPlayer(
    ps: PlayerState,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val current = ps.current ?: return
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Palette.Panel.copy(alpha = 0.96f))
            .border(1.dp, Palette.Ink.copy(alpha = 0.12f), shape)
            .clickable(onClick = onOpen)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            MediaThumb(
                current.uri, !current.isVideo,
                Modifier.size(width = if (current.isVideo) 72.dp else 46.dp, height = 46.dp), corner = 12.dp
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    current.title, color = Palette.TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(current.subtitle, color = Palette.TextLow, fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onClick = onToggle) {
                Icon(
                    if (ps.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (ps.isPlaying) "Pause" else "Play", tint = Palette.TextHi, modifier = Modifier.size(30.dp)
                )
            }
            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Next", tint = Palette.TextHi) }
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close player", tint = Palette.TextLow) }
        }
        Box(Modifier.fillMaxWidth().height(3.dp).background(Palette.Ink.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(ps.progress).fillMaxHeight().background(BrandBrush))
        }
    }
}
