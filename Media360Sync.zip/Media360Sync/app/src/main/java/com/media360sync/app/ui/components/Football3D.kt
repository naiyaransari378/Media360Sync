package com.media360sync.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import com.media360sync.app.ui.theme.Palette
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// ---------- tiny 3D math ----------
private data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = V3(x * s, y * s, z * s)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun norm(): V3 { val l = sqrt(x * x + y * y + z * z); return V3(x / l, y / l, z / l) }

    /** Spin around Y, then tilt around X. */
    fun rotate(spin: Float, tilt: Float): V3 {
        val cs = cos(spin); val ss = sin(spin)
        val x1 = x * cs + z * ss; val z1 = -x * ss + z * cs
        val ct = cos(tilt); val st = sin(tilt)
        return V3(x1, y * ct - z1 * st, y * st + z1 * ct)
    }
}

/**
 * A real truncated icosahedron (classic football): 12 pentagons sit on the
 * icosahedron's vertices, cut at 1/3 along each edge; the middle third of every
 * edge is a hexagon–hexagon seam.
 */
private class BallGeometry(val pentagons: List<List<V3>>, val centers: List<V3>, val seams: List<List<V3>>)

private fun buildBall(): BallGeometry {
    val phi = ((1 + sqrt(5.0)) / 2).toFloat()
    val raw = mutableListOf<V3>()
    for (a in listOf(-1f, 1f)) for (b in listOf(-phi, phi)) {
        raw += V3(0f, a, b); raw += V3(a, b, 0f); raw += V3(b, 0f, a)
    }
    val verts = raw.map { it.norm() }
    fun neighbours(a: V3) = verts.filter { it != a && it.dot(a) > 0.3f }

    val pentagons = verts.map { a ->
        val helper = if (abs(a.x) < 0.9f) V3(1f, 0f, 0f) else V3(0f, 1f, 0f)
        val u = a.cross(helper).norm(); val v = a.cross(u)
        val corners = neighbours(a)
            .sortedBy { val d = it - a; atan2(d.dot(v), d.dot(u)) }
            .map { b -> (a + (b - a) * (1f / 3f)).norm() }
        // subdivide edges so they curve over the sphere
        corners.indices.flatMap { i ->
            val p = corners[i]; val q = corners[(i + 1) % corners.size]
            (0 until 4).map { k -> (p + (q - p) * (k / 4f)).norm() }
        }
    }
    val seams = mutableListOf<List<V3>>()
    for (i in verts.indices) for (j in i + 1 until verts.size) {
        val a = verts[i]; val b = verts[j]
        if (a.dot(b) > 0.3f) {
            val p = a + (b - a) * (1f / 3f); val q = a + (b - a) * (2f / 3f)
            seams += (0..6).map { k -> (p + (q - p) * (k / 6f)).norm() }
        }
    }
    return BallGeometry(pentagons, verts, seams)
}

private val LIGHT = V3(-0.45f, 0.55f, 0.7f).norm()

/**
 * The hero control: a lit, spinning 3D football. Tap to download, drag to spin.
 * While downloading it spins fast and a gradient ring fills with progress.
 */
@Composable
fun Football3D(
    modifier: Modifier = Modifier,
    progress: Float?,           // 0..100, null = no ring
    busy: Boolean,
    success: Boolean,
    error: Boolean,
    haptics: Boolean,
    onTap: () -> Unit,
) {
    val geo = remember { buildBall() }
    val tapAction by rememberUpdatedState(onTap)
    val hapticsOn by rememberUpdatedState(haptics)
    val haptic = LocalHapticFeedback.current

    var spin by remember { mutableFloatStateOf(0.5f) }
    var tilt by remember { mutableFloatStateOf(-0.4f) }
    var flick by remember { mutableFloatStateOf(0f) }
    var pressed by remember { mutableStateOf(false) }

    val speedState = animateFloatAsState(if (busy) 6f else 0.7f, tween(900), label = "speed")
    val scale by animateFloatAsState(
        if (pressed) 0.9f else 1f, spring(dampingRatio = 0.4f, stiffness = 500f), label = "press"
    )
    val ringProgress by animateFloatAsState((progress ?: 0f).coerceIn(0f, 100f), tween(450), label = "ring")
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "glow"
    )
    val glow by animateColorAsState(
        when { error -> Palette.Rose; success -> Palette.Mint; busy -> Palette.Sky; else -> Palette.Violet },
        tween(500), label = "glowColor"
    )

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            withFrameNanos { now ->
                val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                spin += (speedState.value + flick) * dt
                flick *= 0.94f
            }
        }
    }

    val path = remember { Path() }
    val trackColor = Palette.Ink.copy(alpha = 0.08f)
    val shadowColor = Palette.Shadow

    Canvas(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = {
                        if (hapticsOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        flick += 14f
                        tapAction()
                    },
                )
            }
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = {}) { change, drag ->
                    change.consume()
                    spin += drag.x * 0.012f
                    tilt = (tilt - drag.y * 0.012f).coerceIn(-1.3f, 1.3f)
                    flick = (drag.x * 0.4f).coerceIn(-12f, 12f)
                }
            }
    ) {
        val dim = size.minDimension
        val c = center
        val ringR = dim * 0.46f
        val r = dim * 0.335f
        val ringW = dim * 0.028f

        // aura
        drawCircle(
            Brush.radialGradient(listOf(glow.copy(alpha = 0.42f * pulse), Color.Transparent), c, ringR * 1.12f),
            ringR * 1.12f, c
        )
        // ring track
        drawCircle(trackColor, ringR, c, style = Stroke(ringW))
        if (progress != null || success || error) {
            val sweep = if (success || error) 360f else 360f * ringProgress / 100f
            val ringBrush = when {
                error -> Brush.sweepGradient(listOf(Palette.Rose, Palette.Amber, Palette.Rose), c)
                success -> Brush.sweepGradient(listOf(Palette.Mint, Palette.Cyan, Palette.Mint), c)
                else -> Brush.sweepGradient(listOf(Palette.Violet, Palette.Sky, Palette.Cyan, Palette.Violet), c)
            }
            drawArc(
                ringBrush, -90f, sweep, false,
                topLeft = Offset(c.x - ringR, c.y - ringR), size = Size(ringR * 2, ringR * 2),
                style = Stroke(ringW, cap = StrokeCap.Round)
            )
        } else {
            // idle: a satellite dot orbiting the ring
            val a = spin * 0.9f
            drawCircle(Palette.Cyan, ringW * 0.55f, Offset(c.x + cos(a) * ringR, c.y + sin(a) * ringR))
        }

        // contact shadow
        drawOval(
            Brush.radialGradient(listOf(shadowColor, Color.Transparent), Offset(c.x, c.y + r * 1.07f), r * 0.85f),
            topLeft = Offset(c.x - r * 0.85f, c.y + r * 0.93f), size = Size(r * 1.7f, r * 0.3f)
        )

        // leather base, lit from top-left
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White, Color(0xFFE9EBF7), Color(0xFFB0B5D2), Color(0xFF5F6489)),
                Offset(c.x - r * 0.35f, c.y - r * 0.4f), r * 1.75f
            ), r, c
        )

        fun project(p: V3): Offset =
            if (p.z >= 0f) Offset(c.x + p.x * r, c.y - p.y * r)
            else { // fold back-facing points onto the horizon
                val l = sqrt(p.x * p.x + p.y * p.y).coerceAtLeast(1e-4f)
                Offset(c.x + p.x / l * r, c.y - p.y / l * r)
            }

        // pentagon panels
        geo.pentagons.forEachIndexed { i, pts ->
            val rotated = pts.map { it.rotate(spin, tilt) }
            if (rotated.all { it.z < 0f }) return@forEachIndexed
            path.reset()
            rotated.forEachIndexed { k, p ->
                val o = project(p)
                if (k == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
            }
            path.close()
            val lum = geo.centers[i].rotate(spin, tilt).dot(LIGHT).coerceIn(0f, 1f)
            drawPath(path, lerp(Color(0xFF0A0920), Color(0xFF3B3378), lum))
        }

        // stitched hexagon seams
        geo.seams.forEach { seg ->
            var prev: V3? = null
            seg.forEach { raw ->
                val q = raw.rotate(spin, tilt)
                val p0 = prev
                if (p0 != null && q.z > 0f && p0.z > 0f) {
                    drawLine(
                        Color(0xFF2B2D48).copy(alpha = 0.15f + 0.5f * q.z),
                        project(p0), project(q), strokeWidth = dim * 0.006f, cap = StrokeCap.Round
                    )
                }
                prev = q
            }
        }

        // rim falloff (volume) + specular + brand rim light
        drawCircle(
            Brush.radialGradient(
                0f to Color.Transparent, 0.7f to Color.Transparent, 1f to Color(0xFF0A0820).copy(alpha = 0.6f),
                center = c, radius = r
            ), r, c
        )
        val spec = Offset(c.x - r * 0.38f, c.y - r * 0.42f)
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.7f), Color.Transparent), spec, r * 0.42f), r * 0.42f, spec)
        drawCircle(
            Brush.linearGradient(listOf(Color.Transparent, glow.copy(alpha = 0.8f)), Offset(c.x - r, c.y - r), Offset(c.x + r, c.y + r)),
            r, c, style = Stroke(dim * 0.008f)
        )
    }
}
