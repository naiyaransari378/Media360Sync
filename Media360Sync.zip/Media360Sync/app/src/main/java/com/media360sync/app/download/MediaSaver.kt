package com.media360sync.app.download

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

data class SavedMedia(val uri: Uri, val mime: String, val size: Long, val name: String)

/** Moves a finished file into the public gallery: Movies/Media360Sync or Music/Media360Sync. */
object MediaSaver {
    const val FOLDER = "Media360Sync"

    fun mimeOf(ext: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "opus", "ogg" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            else -> "video/mp4"
        }

    fun save(ctx: Context, file: File): SavedMedia {
        val ext = file.extension.lowercase()
        val mime = mimeOf(ext)
        val isAudio = mime.startsWith("audio")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = ctx.contentResolver
            val collection = if (isAudio)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    (if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/" + FOLDER
                )
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: error("Could not create gallery entry")
            try {
                resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out, 1 shl 16) } }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null); throw e
            }
            return SavedMedia(uri, mime, file.length(), file.name)
        }

        @Suppress("DEPRECATION")
        val base = Environment.getExternalStoragePublicDirectory(
            if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        )
        val dir = File(base, FOLDER).apply { mkdirs() }
        var target = File(dir, file.name)
        var i = 1
        while (target.exists()) { target = File(dir, "${file.nameWithoutExtension} ($i).$ext"); i++ }
        file.copyTo(target)
        MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), arrayOf(mime), null)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", target)
        return SavedMedia(uri, mime, target.length(), target.name)
    }
}
