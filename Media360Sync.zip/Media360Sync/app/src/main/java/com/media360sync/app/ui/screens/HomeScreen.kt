package com.media360sync.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.data.AUDIO_FORMATS
import com.media360sync.app.data.Quality
import com.media360sync.app.engine.EngineStatus
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.Phase
import com.media360sync.app.ui.components.ChoiceChips
import com.media360sync.app.ui.components.Football3D
import com.media360sync.app.ui.components.GlassButton
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.GradientButton
import com.media360sync.app.ui.components.SectionLabel
import com.media360sync.app.ui.components.StatusPill
import com.media360sync.app.ui.theme.Palette
import com.media360sync.app.util.Fmt
import com.media360sync.app.util.Platform
import com.media360sync.app.util.UrlUtils

@Composable
fun HomeScreen(vm: MainViewModel, padding: PaddingValues) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val engine by vm.engine.collectAsStateWithLifecycle()
    val dl by vm.download.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current
    val detected = UrlUtils.extractUrl(vm.url)?.let { UrlUtils.detect(it) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(padding).padding(horizontal = 20.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                SectionLabel("Media360Sync", color = Palette.Violet)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Paste. Tap.\nIt’s yours.", color = Palette.TextHi,
                    fontSize = 36.sp, fontWeight = FontWeight.Black, lineHeight = 40.sp
                )
            }
            when (engine.status) {
                EngineStatus.READY -> StatusPill("ONLINE", Palette.Mint)
                EngineStatus.UPDATING -> StatusPill("UPDATING", Palette.Sky)
                EngineStatus.STARTING -> StatusPill("STARTING", Palette.Amber)
                EngineStatus.ERROR -> StatusPill("OFFLINE", Palette.Rose)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Share a link from YouTube, Instagram, TikTok and 1,000+ sites, then tap the ball.",
            color = Palette.TextMid, fontSize = 15.sp, lineHeight = 21.sp
        )
        Spacer(Modifier.height(18.dp))

        AnimatedVisibility(vm.clipboardSuggestion != null && vm.url.isBlank()) {
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 14.dp), corner = 22.dp, padding = 14.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ContentPaste, null, tint = Palette.Cyan)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Link on your clipboard", color = Palette.TextHi, fontWeight = FontWeight.SemiBold)
                        Text(
                            vm.clipboardSuggestion.orEmpty(), color = Palette.TextLow, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        "Use", color = Palette.Cyan, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.useClipboard() }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    IconButton(onClick = vm::dismissClipboard) { Icon(Icons.Rounded.Close, "Dismiss", tint = Palette.TextLow) }
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = vm.url,
                onValueChange = vm::onUrlChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Paste a video link", color = Palette.TextLow) },
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Link, null, tint = Palette.Label) },
                trailingIcon = {
                    if (vm.url.isNotEmpty()) IconButton(onClick = { vm.onUrlChange("") }) {
                        Icon(Icons.Rounded.Close, "Clear", tint = Palette.TextLow)
                    } else IconButton(onClick = { clipboard.getText()?.text?.let(vm::onUrlChange) }) {
                        Icon(Icons.Rounded.ContentPaste, "Paste", tint = Palette.Cyan)
                    }
                },
                shape = RoundedCornerShape(18.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); vm.startDownload() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Palette.Violet, unfocusedBorderColor = Palette.Ink.copy(alpha = 0.14f),
                    focusedContainerColor = Palette.Field, unfocusedContainerColor = Palette.Field,
                    cursorColor = Palette.Sky, focusedTextColor = Palette.TextHi, unfocusedTextColor = Palette.TextHi,
                ),
            )
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                detected?.let { if (it !in Platform.featured) PlatformDot(it, active = true) }
                Platform.featured.forEach { p -> PlatformDot(p, active = detected == p) }
            }
        }

        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Football3D(
                modifier = Modifier.size(300.dp),
                progress = if (dl.phase == Phase.RUNNING) dl.progress ?: 0f else null,
                busy = dl.phase == Phase.RUNNING || dl.phase == Phase.QUEUED,
                success = dl.phase == Phase.DONE,
                error = dl.phase == Phase.FAILED,
                haptics = settings.haptics,
                onTap = { focus.clearFocus(); vm.startDownload() },
            )
        }

        StatusBlock(vm, engine.status)

        if (dl.phase == Phase.DONE) {
            Spacer(Modifier.height(14.dp))
            GradientButton("Play now", Icons.Rounded.PlayArrow, vm::playLatest, Modifier.fillMaxWidth())
        }

        if (dl.phase == Phase.RUNNING) {
            Spacer(Modifier.height(14.dp))
            GlassButton("Cancel download", Icons.Rounded.Stop, vm::cancelDownload, Modifier.fillMaxWidth(), tint = Palette.Rose)
        }

        Spacer(Modifier.height(22.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Save as")
            Spacer(Modifier.height(12.dp))
            ChoiceChips(listOf("Video", "Audio only"), if (settings.audioOnly) 1 else 0, { i ->
                vm.updateSettings { it.copy(audioOnly = i == 1) }
            })
            Spacer(Modifier.height(16.dp))
            if (settings.audioOnly) {
                SectionLabel("Audio format")
                Spacer(Modifier.height(12.dp))
                ChoiceChips(AUDIO_FORMATS.map { it.uppercase() }, AUDIO_FORMATS.indexOf(settings.audioFormat).coerceAtLeast(0), { i ->
                    vm.updateSettings { it.copy(audioFormat = AUDIO_FORMATS[i]) }
                })
            } else {
                SectionLabel("Quality")
                Spacer(Modifier.height(12.dp))
                ChoiceChips(Quality.entries.map { it.label }, settings.quality.ordinal, { i ->
                    vm.updateSettings { it.copy(quality = Quality.entries[i]) }
                })
            }
        }
    }
}

@Composable
private fun StatusBlock(vm: MainViewModel, engine: EngineStatus) {
    val dl by vm.download.collectAsStateWithLifecycle()
    val (headline, detail, color) = when {
        engine == EngineStatus.STARTING -> Triple("Warming up the engine…", "First launch unpacks yt-dlp. This takes a moment.", Palette.Amber)
        engine == EngineStatus.ERROR -> Triple("Engine offline", "Restart the app. If it continues, reinstall.", Palette.Rose)
        dl.phase == Phase.RUNNING -> {
            val pct = dl.progress?.let { "${it.toInt()}%" } ?: "Starting"
            val eta = Fmt.eta(dl.eta).let { if (it.isEmpty()) "" else " • $it left" }
            val queue = if (dl.waiting > 0) " • ${dl.waiting} queued" else ""
            Triple("$pct$eta", "Downloading from ${dl.platform.ifEmpty { "the web" }}$queue", Palette.Sky)
        }
        dl.phase == Phase.QUEUED -> Triple("Queued", "${dl.waiting} waiting for a connection", Palette.Sky)
        dl.phase == Phase.DONE -> Triple("Saved to your gallery", dl.title, Palette.Mint)
        dl.phase == Phase.FAILED -> Triple("Couldn’t download", dl.error.orEmpty(), Palette.Rose)
        vm.url.isBlank() -> Triple("Tap the ball to download", "Paste a link above, or share one to this app.", Palette.TextHi)
        else -> Triple("Ready — tap the ball", "Saves to Movies/Media360Sync", Palette.TextHi)
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(headline, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        if (detail.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                detail, color = Palette.TextMid, fontSize = 14.sp, textAlign = TextAlign.Center,
                maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PlatformDot(p: Platform, active: Boolean) {
    val c = Color(p.color)
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape)
            .background(if (active) c.copy(alpha = 0.18f) else Palette.Ink.copy(alpha = 0.04f))
            .border(1.dp, if (active) c.copy(alpha = 0.6f) else Palette.Ink.copy(alpha = 0.1f), shape)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(if (active) c else c.copy(alpha = 0.45f)))
        Spacer(Modifier.width(6.dp))
        Text(
            p.label, color = if (active) Palette.TextHi else Palette.TextLow,
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold
        )
    }
}
