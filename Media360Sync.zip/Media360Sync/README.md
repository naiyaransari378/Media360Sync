# Media360Sync — Android video downloader

Native Kotlin + Jetpack Compose app. Glassmorphism UI, a real 3D football you tap to
download, yt-dlp + FFmpeg engine with Stable/Nightly auto-update.

## Get the APK (easiest — no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder.
2. Open the repo's **Actions** tab → **Build APK** → **Run workflow** (it also runs on every push to `main`).
3. After ~10 minutes, open the finished run and download:
   - **Media360Sync-APK** → install directly on phones
   - **Media360Sync-AAB** → `app-release.aab` for app stores
   - `app-arm64-v8a-release.apk` → almost every modern phone
   - `app-universal-release.apk` → works everywhere (bigger)

## Build in Android Studio
Open this folder (Ladybug or newer, JDK 17). If asked, let it create the Gradle wrapper,
then **Build → Build APK(s)**. From a terminal with Gradle 8.9: `gradle assembleRelease`.

## How it works
- **Share** a link from YouTube / Instagram / TikTok / Facebook / X → app opens with the link filled in → **tap the ball**.
- Or copy a link — the app offers it from the clipboard when you open it.
- Ball spins fast and the ring fills with progress; a notification shows progress + Cancel.
- Videos save to `Movies/Media360Sync`, audio to `Music/Media360Sync` (visible in Gallery).
- Downloads queue one after another (WorkManager foreground worker, survives leaving the app).
- Engine tab: version, last update, one-tap Stable/Nightly update, daily auto-update on Wi‑Fi.

## Project map
```
engine/EngineManager.kt   yt-dlp + FFmpeg init, version, self-update
engine/UpdateWorker.kt    daily background engine update
download/DownloadWorker.kt  the download job (format, progress, errors)
download/MediaSaver.kt    saves into the public gallery (MediaStore)
ui/components/Football3D.kt  3D truncated-icosahedron ball, tap + drag
ui/components/Glass.kt    glass cards, buttons, chips, aurora background
ui/screens/*              Kick (home), Library, Engine, Settings
```

## Before you publish
- **Signing:** without secrets, builds use a temporary debug key. To sign with your own key:
  1. `keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias media360`
  2. `base64 -w0 release.jks` and copy the output
  3. GitHub repo → Settings → Secrets → Actions, add `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
  Keep `release.jks` safe — losing it means you can't ship updates.
- **Google Play rejects YouTube downloaders.** Distribute via GitHub Releases, your website, or F-Droid.
- APK size is ~70–110 MB per ABI because Python and FFmpeg are bundled.
- Library version: `io.github.junkfood02.youtubedl-android` 0.17.2 — check Maven Central for newer.
- Respect copyright and each platform's terms: download only what you own or have permission to save.
