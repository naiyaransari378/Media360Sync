package com.media360sync.app.download

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.media360sync.app.data.AppSettings
import com.media360sync.app.data.HistoryItem
import com.media360sync.app.data.HistoryRepository
import com.media360sync.app.data.SettingsRepository
import com.media360sync.app.engine.EngineManager
import com.media360sync.app.util.Fmt
import com.media360sync.app.util.Notifications
import com.media360sync.app.util.Platform
import com.media360sync.app.util.UrlUtils
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val notifId = id.hashCode()
    private val processId = id.toString()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) { run() }

    private suspend fun run(): Result {
        val url = inputData.getString(KEY_URL) ?: return fail("No link was provided")
        val platform = UrlUtils.detect(url)
        val settings = SettingsRepository(applicationContext).settings.first()

        runCatching { setForeground(foreground(platform, "Preparing…", 0, true)) }
        setProgress(workDataOf(KEY_PLATFORM to platform.label, KEY_PROGRESS to -1f))

        if (!EngineManager.awaitReady()) return fail("The download engine failed to start. Reopen the app.")

        val dir = File(applicationContext.cacheDir, "dl/$processId").apply { deleteRecursively(); mkdirs() }
        var lastEmit = 0L

        return try {
            YoutubeDL.getInstance().execute(buildRequest(url, dir, settings), processId) { progress, eta, line ->
                if (isStopped) {
                    YoutubeDL.getInstance().destroyProcessById(processId)
                    return@execute
                }
                val now = SystemClock.uptimeMillis()
                if (now - lastEmit < 400) return@execute
                lastEmit = now
                setProgressAsync(
                    workDataOf(
                        KEY_PROGRESS to progress, KEY_ETA to eta,
                        KEY_LINE to line.take(160), KEY_PLATFORM to platform.label,
                    )
                )
                val p = progress.toInt().coerceIn(0, 100)
                val text = if (progress >= 0) "$p% • ${Fmt.eta(eta)} left" else "Starting…"
                setForegroundAsync(foreground(platform, text, p, progress < 0))
            }

            val files = dir.walkTopDown()
                .filter { it.isFile && it.extension.lowercase() in MEDIA_EXT }
                .toList()
            if (files.isEmpty()) return fail("No video or audio was found at this link")

            val history = HistoryRepository.get(applicationContext)
            var title = ""
            files.forEach { f ->
                val saved = MediaSaver.save(applicationContext, f)
                title = f.nameWithoutExtension.replace(Regex("""\s\[[^\]]+]$"""), "")
                history.add(
                    HistoryItem(
                        id = System.nanoTime(), title = title, uri = saved.uri.toString(), mime = saved.mime,
                        platform = platform.label, sourceUrl = url, time = System.currentTimeMillis(), size = saved.size,
                    )
                )
            }
            val summary = if (files.size > 1) "${files.size} files saved" else title
            Notifications.result(applicationContext, notifId + 1, "Download complete", summary)
            Result.success(workDataOf(KEY_TITLE to summary, KEY_COUNT to files.size))
        } catch (e: YoutubeDL.CanceledException) {
            fail("Download cancelled", notify = false)
        } catch (e: Exception) {
            if (isStopped) fail("Download cancelled", notify = false) else fail(friendly(e.message))
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun buildRequest(url: String, dir: File, s: AppSettings) = YoutubeDLRequest(url).apply {
        addOption("-o", "${dir.absolutePath}/%(title).100B [%(id)s].%(ext)s")
        addOption("--no-mtime")
        addOption("-N", "4") // parallel fragments = faster on HLS/DASH
        addOption(if (s.noPlaylist) "--no-playlist" else "--yes-playlist")
        if (s.audioOnly) {
            addOption("-x")
            addOption("--audio-format", s.audioFormat)
            addOption("--audio-quality", "0")
        } else {
            addOption("-f", "bv*+ba/b")
            s.quality.height?.let { addOption("-S", "res:$it,ext:mp4:m4a") }
            addOption("--merge-output-format", "mp4")
        }
        if (s.embedThumbnail) addOption("--embed-thumbnail")
        if (s.embedMetadata) addOption("--embed-metadata")
    }

    private fun foreground(platform: Platform, text: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val cancel = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
        val n = Notifications.progress(
            applicationContext, "Downloading from ${platform.label}", text, progress, indeterminate, cancel
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ForegroundInfo(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(notifId, n)
    }

    private fun fail(message: String, notify: Boolean = true): Result {
        if (notify) Notifications.result(applicationContext, notifId + 1, "Download failed", message)
        return Result.failure(workDataOf(KEY_ERROR to message))
    }

    private fun friendly(raw: String?): String {
        val m = raw.orEmpty()
        return when {
            m.contains("Unsupported URL", true) -> "This link isn't supported. Try the direct post or video link."
            m.contains("login", true) || m.contains("private", true) || m.contains("cookies", true) ->
                "This content is private or needs a login."
            m.contains("429") -> "The site is rate-limiting. Wait a few minutes and try again."
            m.contains("Unable to extract", true) || m.contains("extractor", true) ->
                "The site changed. Update the engine in the Engine tab, then retry."
            m.contains("timed out", true) || m.contains("resolve host", true) -> "Network problem. Check your connection."
            else -> m.lines().lastOrNull { it.contains("ERROR") }?.substringAfter("ERROR:")?.trim()
                ?.take(200) ?: "Download failed. Update the engine and try again."
        }
    }

    companion object {
        const val TAG = "media_download"
        const val QUEUE = "download_queue"
        const val KEY_URL = "url"
        const val KEY_PROGRESS = "progress"
        const val KEY_ETA = "eta"
        const val KEY_LINE = "line"
        const val KEY_PLATFORM = "platform"
        const val KEY_TITLE = "title"
        const val KEY_COUNT = "count"
        const val KEY_ERROR = "error"
        private val MEDIA_EXT = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp", "m4a", "mp3", "opus", "ogg", "aac", "flac", "wav")

        fun input(url: String): Data = workDataOf(KEY_URL to url)
    }
}
