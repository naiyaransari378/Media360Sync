package com.media360sync.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

enum class Quality(val label: String, val height: Int?) {
    BEST("Best", null), UHD("4K", 2160), FHD("1080p", 1080), HD("720p", 720), SD("480p", 480)
}

enum class EngineChannel(val label: String) { STABLE("Stable"), NIGHTLY("Nightly") }

enum class ThemeMode(val label: String) { SYSTEM("Auto"), LIGHT("Day"), DARK("Night") }

val AUDIO_FORMATS = listOf("mp3", "m4a", "opus")

data class AppSettings(
    val quality: Quality = Quality.BEST,
    val audioOnly: Boolean = false,
    val audioFormat: String = "mp3",
    val embedThumbnail: Boolean = true,
    val embedMetadata: Boolean = true,
    val noPlaylist: Boolean = true,
    val clipboardDetect: Boolean = true,
    val autoDownloadOnShare: Boolean = false,
    val haptics: Boolean = true,
    val autoUpdate: Boolean = true,
    val channel: EngineChannel = EngineChannel.STABLE,
    val lastEngineUpdate: Long = 0L,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
)

class SettingsRepository(context: Context) {
    private val ds = context.applicationContext.dataStore

    private object K {
        val quality = stringPreferencesKey("quality")
        val audioOnly = booleanPreferencesKey("audio_only")
        val audioFormat = stringPreferencesKey("audio_format")
        val embedThumb = booleanPreferencesKey("embed_thumb")
        val embedMeta = booleanPreferencesKey("embed_meta")
        val noPlaylist = booleanPreferencesKey("no_playlist")
        val clipboard = booleanPreferencesKey("clipboard_detect")
        val autoShare = booleanPreferencesKey("auto_share")
        val haptics = booleanPreferencesKey("haptics")
        val autoUpdate = booleanPreferencesKey("auto_update")
        val channel = stringPreferencesKey("channel")
        val lastUpdate = longPreferencesKey("last_update")
        val theme = stringPreferencesKey("theme")
    }

    val settings: Flow<AppSettings> = ds.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                quality = p[K.quality]?.let { v -> Quality.entries.firstOrNull { it.name == v } } ?: d.quality,
                audioOnly = p[K.audioOnly] ?: d.audioOnly,
                audioFormat = p[K.audioFormat] ?: d.audioFormat,
                embedThumbnail = p[K.embedThumb] ?: d.embedThumbnail,
                embedMetadata = p[K.embedMeta] ?: d.embedMetadata,
                noPlaylist = p[K.noPlaylist] ?: d.noPlaylist,
                clipboardDetect = p[K.clipboard] ?: d.clipboardDetect,
                autoDownloadOnShare = p[K.autoShare] ?: d.autoDownloadOnShare,
                haptics = p[K.haptics] ?: d.haptics,
                autoUpdate = p[K.autoUpdate] ?: d.autoUpdate,
                channel = p[K.channel]?.let { v -> EngineChannel.entries.firstOrNull { it.name == v } } ?: d.channel,
                lastEngineUpdate = p[K.lastUpdate] ?: 0L,
                themeMode = p[K.theme]?.let { v -> ThemeMode.entries.firstOrNull { it.name == v } } ?: d.themeMode,
            )
        }

    /** Saves user-editable fields (engine timestamp is written separately). */
    suspend fun save(s: AppSettings) {
        ds.edit { p ->
            p[K.quality] = s.quality.name
            p[K.audioOnly] = s.audioOnly
            p[K.audioFormat] = s.audioFormat
            p[K.embedThumb] = s.embedThumbnail
            p[K.embedMeta] = s.embedMetadata
            p[K.noPlaylist] = s.noPlaylist
            p[K.clipboard] = s.clipboardDetect
            p[K.autoShare] = s.autoDownloadOnShare
            p[K.haptics] = s.haptics
            p[K.autoUpdate] = s.autoUpdate
            p[K.channel] = s.channel.name
            p[K.theme] = s.themeMode.name
        }
    }

    suspend fun setLastUpdate(time: Long) {
        ds.edit { it[K.lastUpdate] = time }
    }
}
