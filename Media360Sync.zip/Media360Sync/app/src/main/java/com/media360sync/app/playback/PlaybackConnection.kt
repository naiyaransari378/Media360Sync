package com.media360sync.app.playback

import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.media360sync.app.data.HistoryItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class QueueEntry(
    val id: String,
    val title: String,
    val subtitle: String,
    val uri: String,
    val isVideo: Boolean,
)

data class PlayerState(
    val current: QueueEntry? = null,
    val index: Int = -1,
    val queue: List<QueueEntry> = emptyList(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
) {
    val progress: Float get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}

private const val EXTRA_URI = "uri"
private const val EXTRA_VIDEO = "video"

fun HistoryItem.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(platform)
            .setExtras(Bundle().apply { putString(EXTRA_URI, uri); putBoolean(EXTRA_VIDEO, !isAudio) })
            .build()
    )
    .build()

private fun MediaItem.toEntry(): QueueEntry {
    val extras = mediaMetadata.extras
    return QueueEntry(
        id = mediaId,
        title = mediaMetadata.title?.toString().orEmpty(),
        subtitle = mediaMetadata.artist?.toString().orEmpty(),
        uri = extras?.getString(EXTRA_URI).orEmpty(),
        isVideo = extras?.getBoolean(EXTRA_VIDEO) ?: false,
    )
}

/** The UI side of the player: talks to PlaybackService through a MediaController. */
class PlaybackConnection(context: Context, scope: CoroutineScope) {
    private val app = context.applicationContext
    private val future = MediaController.Builder(
        app, SessionToken(app, ComponentName(app, PlaybackService::class.java))
    ).buildAsync()

    /** Exposed for the video surface (PlayerView). */
    var controller by mutableStateOf<MediaController?>(null)
        private set

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 2)
    val errors: SharedFlow<String> = _errors.asSharedFlow()

    private var pending: ((MediaController) -> Unit)? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()
        override fun onPlayerError(error: PlaybackException) {
            _errors.tryEmit("Can't play this file. It may have been moved or deleted.")
        }
    }

    init {
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            pending?.invoke(c)
            pending = null
            sync()
        }, ContextCompat.getMainExecutor(app))

        // Smooth progress while playing
        scope.launch {
            while (isActive) {
                val c = controller
                if (c != null && c.isPlaying) {
                    _state.update {
                        it.copy(positionMs = c.currentPosition.coerceAtLeast(0), durationMs = c.duration.coerceAtLeast(0))
                    }
                }
                delay(500)
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        val queue = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).toEntry() }
        val idx = c.currentMediaItemIndex
        _state.value = PlayerState(
            current = if (queue.isEmpty()) null else queue.getOrNull(idx),
            index = idx,
            queue = queue,
            isPlaying = c.isPlaying,
            isBuffering = c.playbackState == Player.STATE_BUFFERING,
            positionMs = c.currentPosition.coerceAtLeast(0),
            durationMs = c.duration.coerceAtLeast(0),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
        )
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending = block
    }

    fun playList(items: List<HistoryItem>, start: Int, shuffle: Boolean = false) = withController { c ->
        if (items.isEmpty()) return@withController
        c.setMediaItems(items.map { it.toMediaItem() }, start.coerceIn(0, items.lastIndex), 0L)
        c.shuffleModeEnabled = shuffle
        c.prepare()
        c.play()
    }

    fun togglePlay() = withController { c ->
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun next() = withController { it.seekToNextMediaItem() }
    fun previous() = withController { it.seekToPrevious() }
    fun skipTo(index: Int) = withController { it.seekToDefaultPosition(index); it.play() }

    fun seekTo(ms: Long) = withController { c ->
        c.seekTo(ms)
        _state.update { it.copy(positionMs = ms) }
    }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = withController { c ->
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun stop() = withController { it.stop(); it.clearMediaItems() }

    fun release() {
        controller?.removeListener(listener)
        MediaController.releaseFuture(future)
        controller = null
    }
}
