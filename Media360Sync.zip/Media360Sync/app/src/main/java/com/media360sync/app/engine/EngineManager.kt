package com.media360sync.app.engine

import android.content.Context
import com.media360sync.app.data.EngineChannel
import com.media360sync.app.data.SettingsRepository
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class EngineStatus { STARTING, READY, UPDATING, ERROR }

data class EngineState(
    val status: EngineStatus = EngineStatus.STARTING,
    val version: String? = null,
    val lastUpdate: Long = 0L,
    val message: String? = null,
)

/** Owns the embedded yt-dlp + FFmpeg runtime: startup, version and self-updates. */
object EngineManager {
    private val _state = MutableStateFlow(EngineState())
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private val ready = CompletableDeferred<Boolean>()
    private val updateLock = Mutex()
    private const val DAY = 24L * 60 * 60 * 1000

    fun initialize(context: Context, scope: CoroutineScope) {
        val app = context.applicationContext
        scope.launch(Dispatchers.IO) {
            val repo = SettingsRepository(app)
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                val s = repo.settings.first()
                _state.value = EngineState(
                    EngineStatus.READY, YoutubeDL.getInstance().version(app), s.lastEngineUpdate
                )
                ready.complete(true)

                if (s.autoUpdate) {
                    UpdateWorker.schedule(app)
                    if (System.currentTimeMillis() - s.lastEngineUpdate > DAY) update(app, s.channel)
                }
            } catch (e: Throwable) {
                _state.value = EngineState(EngineStatus.ERROR, message = "Engine failed to start: ${e.message}")
                ready.complete(false)
            }
        }
    }

    suspend fun awaitReady(): Boolean = ready.await()

    suspend fun update(context: Context, channel: EngineChannel): String = updateLock.withLock {
        if (!awaitReady()) return "Engine is not available"
        val app = context.applicationContext
        _state.update { it.copy(status = EngineStatus.UPDATING, message = "Checking ${channel.label} channel…") }
        withContext(Dispatchers.IO) {
            try {
                val ch = when (channel) {
                    EngineChannel.NIGHTLY -> YoutubeDL.UpdateChannel.NIGHTLY
                    EngineChannel.STABLE -> YoutubeDL.UpdateChannel.STABLE
                }
                val status = YoutubeDL.getInstance().updateYoutubeDL(app, ch)
                val now = System.currentTimeMillis()
                SettingsRepository(app).setLastUpdate(now)
                val version = YoutubeDL.getInstance().version(app)
                val msg = if (status == YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE)
                    "Already on the latest ${channel.label} build" else "Updated to $version"
                _state.value = EngineState(EngineStatus.READY, version, now, msg)
                msg
            } catch (e: Throwable) {
                val msg = "Update failed: ${e.message ?: "check your connection"}"
                _state.update { it.copy(status = EngineStatus.READY, message = msg) }
                msg
            }
        }
    }
}
