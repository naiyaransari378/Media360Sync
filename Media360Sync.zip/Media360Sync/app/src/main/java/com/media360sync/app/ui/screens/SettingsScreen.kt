package com.media360sync.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.media360sync.app.data.AUDIO_FORMATS
import com.media360sync.app.data.Quality
import com.media360sync.app.ui.MainViewModel
import com.media360sync.app.ui.components.ChoiceChips
import com.media360sync.app.ui.components.GlassCard
import com.media360sync.app.ui.components.ScreenHeader
import com.media360sync.app.ui.components.SectionLabel
import com.media360sync.app.ui.components.SwitchRow
import com.media360sync.app.ui.theme.Palette

@Composable
fun SettingsScreen(vm: MainViewModel, padding: PaddingValues) {
    val s by vm.settings.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(padding).padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Settings", "Make it yours", null)
        Spacer(Modifier.height(20.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Video")
            Spacer(Modifier.height(12.dp))
            Text("Default quality", color = Palette.TextHi, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            ChoiceChips(Quality.entries.map { it.label }, s.quality.ordinal, { i ->
                vm.updateSettings { it.copy(quality = Quality.entries[i]) }
            })
            Spacer(Modifier.height(16.dp))
            Text("Audio format", color = Palette.TextHi, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            ChoiceChips(AUDIO_FORMATS.map { it.uppercase() }, AUDIO_FORMATS.indexOf(s.audioFormat).coerceAtLeast(0), { i ->
                vm.updateSettings { it.copy(audioFormat = AUDIO_FORMATS[i]) }
            })
            Spacer(Modifier.height(8.dp))
            SwitchRow("Embed thumbnail", "Cover art shows in your gallery and music player", s.embedThumbnail) { on ->
                vm.updateSettings { it.copy(embedThumbnail = on) }
            }
            SwitchRow("Embed title & artist", "Writes metadata into the file", s.embedMetadata) { on ->
                vm.updateSettings { it.copy(embedMetadata = on) }
            }
            SwitchRow("Single video only", "Ignore the playlist when a link belongs to one", s.noPlaylist) { on ->
                vm.updateSettings { it.copy(noPlaylist = on) }
            }
        }

        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Behaviour")
            Spacer(Modifier.height(4.dp))
            SwitchRow("Detect copied links", "Offers a link from your clipboard when you open the app", s.clipboardDetect) { on ->
                vm.updateSettings { it.copy(clipboardDetect = on) }
            }
            SwitchRow("Download as soon as shared", "Skip the tap when you share a link to the app", s.autoDownloadOnShare) { on ->
                vm.updateSettings { it.copy(autoDownloadOnShare = on) }
            }
            SwitchRow("Haptic feedback", "Feel the kick when you tap the ball", s.haptics) { on ->
                vm.updateSettings { it.copy(haptics = on) }
            }
        }

        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("About")
            Spacer(Modifier.height(10.dp))
            Text("Media360Sync 1.0.0", color = Palette.TextHi, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Powered by yt-dlp and FFmpeg. Only download content you own or have permission to save, " +
                    "and follow each platform’s terms.",
                color = Palette.TextLow, fontSize = 13.sp, lineHeight = 18.sp
            )
        }
    }
}
